-- ======================================================= --
--														   --
--		Name StoredProcedure: MonthlyTrafficSummary		   --
--		Purpose of the procedure: Generate Monthly Traffic --
--		of Service and Country specify by the user		   --
--														   --
-- ======================================================= --
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [MonthlyTrafficSummary]
	-- Add the parameters for the stored procedure here
	@Date1 Date,
	@Date2 Date,
	@path NVARCHAR(40),
	@sheet NVARCHAR(20)
AS
BEGIN
			SELECT cust.serviceId as service_id, cc1.countryName as fromCountry, cc2.countryName as toCountry, fromTel as tel, sum(duration) as duration 
		INTO #Traffics
		FROM Calls
			LEFT JOIN callingCode cc1 ON cc1.countryCode=Calls.fromCode
			LEFT JOIN callingCode cc2 ON cc2.countryCode=Calls.toCode
			LEFT JOIN Customer cust ON cust.telephone=Calls.fromTel
		WHERE callDate between @Date1 and @Date2
		GROUP by cust.serviceId, cc1.countryName, cc2.countryName, fromTel


	 DECLARE @sql VARCHAR(1600)= 'INSERT INTO OPENROWSET(''Microsoft.ACE.OLEDB.12.0'', ''Excel 12.0; Database=C:\Users\sbart\Desktop\Files\' + @path 
	 + ''', ''SELECT serviceName,fromCountry,toCountry,duration FROM [' + @sheet + '$]'')'
	 + 'SELECT  Service.serviceName,fromCountry,toCountry,duration FROM #Traffics, Service
		WHERE Service.serviceId = #Traffics.service_id 	ORDER BY 1';
	 EXEC(@sql)


END
GO
