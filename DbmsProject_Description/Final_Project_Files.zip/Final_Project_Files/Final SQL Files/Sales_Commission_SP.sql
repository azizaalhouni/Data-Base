-- ================================================
--
--		Name StoredProcedure: SalesCommission
--		Purpose of the procedure: Export Monthly 
--		Commisions for the Sale Persons employee
--		of the company. User insert the specific
--		month to generate the report
--
-- ================================================

USE [InternationalServiceCompanies]
Go

CREATE PROCEDURE [SalesCommission]
 @Month int
AS
BEGIN
	select custId, commission,salesRedId,toCode,toTel,duration,callDate,callTime,peekStart,offpeekStart,r.peek,r.offpeek,r.effectiveDate,
	(select case when calltime >= peekstart AND calltime < offPeekStart then Round((duration/60.0)*peek,2)
	 else Round((duration/60.0)*offpeek,2) end) AS Cost
	 INTO #BillsTemp
	from calls c,customer m,peekoffpeek p,Rates r
	where m.telephone = c.fromTel and Month(c.callDate) = @Month
	and  p.CountryCode = c.fromCode and p.serviceid = m.serviceid 
-- Get the rate
	and r.serviceid = m.serviceid 
	and r.Country = c.fromCode 
	and r.effectiveDate = (select MAX(r.effectiveDate) FROM Rates r, Calls WHERE r.effectiveDate <= c.callDate)
	and r.destination = c.toCode
	order by custId

-- Creates TotalCost Table
	SELECT custId, commission, salesRedId, SUM(Cost) as TotalCost  
	INTO #CommissionTable
	FROM #BillsTemp
	GROUP BY custId, commission, salesRedId

-- Creates Commission Table
	SELECT  s.SaledId, s.name, SUM(Round(c.TotalCost * c.commission, 2)) as TotalCommission 
	INTO #Final_Table
	FROM #CommissionTable c, SalesRep s
	WHERE s.SaledId = c.salesRedId
	GROUP BY s.SaledId, s.name

DECLARE @sql2 VARCHAR(500);
SET @sql2 = 'insert into OPENROWSET(
''Microsoft.ACE.OLEDB.12.0'',
''Excel 12.0; Database=C:\Users\sbart\Desktop\Files\Commission.xlsx'',
''SELECT * FROM [January$]'') select SaledId, name, TotalCommission From #Final_Table'
EXEC (@sql2);
END
