-- ============================================================
--
--		Name StoredProcedure: CustomerBill
--		Purpose of the procedure: Generates a Monthly Customer
--		Bill where gives all the information of the specific
--		customer added manually by the user
--		
-- ============================================================

USE[InternationalServiceCompanies]
GO

CREATE PROCEDURE CUSTOMER_BILL(
@FNAME1 VARCHAR(255),
@LNAME1 VARCHAR(255),
@MONTH1 INT,
@PHONENUMBER BIGINT
)
AS
BEGIN
----------------------Calculate the cost
Declare @fName varchar(255),@lName varchar(255),@telephone bigint,@month int,@effectiveDate date
set @fName = @FNAME1; set @lName = @lName1;set @telephone = @PHONENUMBER;set @month = @MONTH1

--set @fName = 'Thomas'; set @lName = 'Tripp';set @telephone = '2129695507';set @month = '12'

	select fname,lname,toCode,toTel,duration,callDate,callTime,peekStart,offpeekStart,r.peek,r.offpeek,
	---Get the effectiveDate
	effectiveDate ,
	(select (case when calltime>=peekstart and callTime<offPeekStart  then Round(duration/60.0 *peek,2)
	 when calltime >= offPeekStart or callTime<peekStart 
	then Round(duration/60.0 *offpeek,2)  end)) AS cost
	Into #cust1
 from calls c,customer m,peekoffpeek p,Rates r
 where fname = @fName and lName = @lName  and fromTel =  @telephone and Month(c.callDate) = @month
and  p.CountryCode = c.fromCode and p.serviceid = m.serviceid 
--get the rate
and r.serviceid = m.serviceid and r.Country = c.fromCode and
 r.effectiveDate = (select MAX(r.effectiveDate) FROM Rates r, Calls WHERE r.effectiveDate <= c.callDate) 
 and r.destination = c.toCode
order by callDate

SELECT SUM(Cost) as Amount_Due  
	FROM #cust1
	
	DECLARE @sql2 VARCHAR(500);
SET @sql2 = 'insert into OPENROWSET(
''Microsoft.ACE.OLEDB.12.0'',
''Excel 12.0; Database=Z:\DB\CUST.xlsx'',
''SELECT * FROM [Sheet1$]'') select sUM(COST) From #CUST1'
EXEC (@sql2);
Drop table #cust1
	END