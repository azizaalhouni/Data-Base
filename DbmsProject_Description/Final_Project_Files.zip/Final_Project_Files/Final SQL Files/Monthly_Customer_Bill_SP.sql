-- ============================================================
--
--		Name StoredProcedure: CustomerBill
--		Purpose of the procedure: Generates a Monthly Customer
--		Bill where gives all the information of the specific
--		customer added manually by the user
--		
-- ============================================================


USE[InternationalServiceCompanies]
Go
CREATE PROCEDURE CustomerBill (
@FNAME1 VARCHAR(255),
@LNAME1 VARCHAR(255),
@MONTH1 INT,
@PHONENUMBER BIGINT,
@path varchar(255),
@BillDetails varchar(255),
@AmountDue varchar(255)
)
AS
BEGIN
----------------------Calculate the cost
Declare @fName varchar(255),@lName varchar(255),@telephone bigint,@month int,@effectiveDate date
set @fName = @FNAME1; set @lName = @lName1;set @telephone = @phoneNumber;set @month = @MONTH1

	select fname,lname,address,telephone,toCode,toTel,duration,callDate,callTime,peekStart,offpeekStart,r.peek,r.offpeek,
	---Get the effectiveDate
	effectiveDate,d.countryName,
	(select (case when calltime>=peekstart and callTime<offPeekStart  then Round(duration/60.0 *peek,2)
	 when calltime >= offPeekStart or callTime<peekStart 
	then Round(duration/60.0 *offpeek,2)  end)) AS cost
	Into #cust1
 from calls c,customer m,peekoffpeek p,Rates r,CallingCode d
 where fname = @fName and lName = @lName  and c.toCode = d.countryCode and fromTel =  @telephone and Month(c.callDate) = @month
and  p.CountryCode = c.fromCode and p.serviceid = m.serviceid 
--get the rate
and r.serviceid = m.serviceid and r.Country = c.fromCode and
 r.effectiveDate = (select MAX(r.effectiveDate) FROM Rates r, Calls WHERE r.effectiveDate <= c.callDate) 
 and r.destination = c.toCode
order by callDate

SELECT toTel,countryName,duration,callTime,cost 
	FROM #cust1
	SELECT fName,lName,address,telephone,SUM(COST)AS AMOUNT_DUE 
	INTO #AMOUNT_DUE FROM #CUST1 group by fName,lName,address,telephone
	
	DECLARE @sql2 VARCHAR(500),@sql1 varchar(500);
	--Get the Customer's Bill Details ---
SET @sql2 = 'insert into OPENROWSET(
''Microsoft.ACE.OLEDB.12.0'',
''Excel 12.0; Database='+@path+''', 
''SELECT * FROM ['+@BillDetails+']'') select toTel ,countryName,duration,callTime,cost From #CUST1 '

---Get the Customer's info plus the amount Due
SET @sql1 = 'insert into OPENROWSET(
''Microsoft.ACE.OLEDB.12.0'',
''Excel 12.0; Database='+@Path+''', 
''SELECT * FROM ['+@AmountDue+']'') select * From #Amount_due '

EXEC (@sql2);
EXEC (@sql1);
Drop table #cust1
Drop table #AMOUNT_DUE
	END